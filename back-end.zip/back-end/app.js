const express = require('express');
const app = express();
const connectDB = require('./config/db');
const session = require('express-session');
const cors = require('cors');
app.use(cors({
  origin: 'https://randomrawat.github.io/OTP-Auth-System/', 
  methods: ['GET', 'POST', 'PUT', 'DELETE'],
  credentials: true 
}));
connectDB();

app.use(express.json()); 

app.use(session({
  secret: 'supersecretkey',
  resave: false,
  saveUninitialized: true,
  cookie: { secure: false } 
}));

const authRoutes = require('./routes/authRoutes');  
app.use('/api/auth', authRoutes);

const PORT = 3000;
app.listen(PORT, () => console.log(`Server is running on port ${PORT}`));

