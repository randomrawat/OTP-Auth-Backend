const User = require('../models/User');
const nodemailer = require('nodemailer');
const crypto = require('crypto');

const transporter = nodemailer.createTransport({
  service: 'Gmail',
  auth: {
    user: 'shubhamrawat8249@gmail.com',
    pass: 'dugsokmgnxeopenb',
  },
});

const generateOTP = () => {
  return crypto.randomInt(100000, 999999).toString();
};

exports.register = async (req, res) => {
  try {
    const { name, email, password } = req.body;
    let user = await User.findOne({ email});

    if (user) {
      return res.status(400).json({ message: 'User already exists' });
    }   
    const otp = generateOTP();  
    const otpEExpiry = new Date(Date.now() + 10 * 60 * 1000); // OTP valid for 10 minutes
    user = new User({ name, email, password, otp, otpEExpiry });
    await user.save();

    await transporter.sendMail({
        from: 'shubhamrawat8249@gmail.com',
        to: email,
        subject: 'OTP for Registration',
        text: `Your OTP is ${otp}. It is valid for 10 minutes.`,
    });

    res.status(201).json({ message: 'User registered successfully. Please check your email for the OTP.' });
  } catch (error) {
    console.error('Error registering user:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
}

exports.verifyOTP = async (req, res) => {
  try {
    const { email, otp } = req.body;
    const user  = await User.findOne({email });
    if (!user) {
      return res.status(400).json({ message: 'User not found' });
    }
    if(user.isVerified) {
      return res.status(400).json({ message: 'User already verified' });
    }

    if (user.otp !== otp) {
      return res.status(400).json({ message: 'Invalid OTP' });
    }

    if (user.otpEExpiry < Date.now()) {
      return res.status(400).json({ message: 'OTP expired' });
    }
    user.isVerified = true;
    user.otp = undefined;
    user.otpEExpiry = undefined;
    await user.save();

    res.status(200).json({ message: 'OTP verified successfully' });
  } catch (error) {
    console.error('Error verifying OTP:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
}

exports.resendOTP = async (req, res) => {
  try {
    const { email } = req.body;
    const user = await User.findOne({ email });
    if (!user) {
      return res.status(400).json({ message: 'User not found' });
    }
    if (user.isVerified) {
      return res.status(400).json({ message: 'User already verified' });
    }

    const otp = generateOTP();
    const otpEExpiry = new Date(Date.now() + 10 * 60 * 1000); // OTP valid for 10 minutes
    user.otp = otp;
    user.otpEExpiry = otpEExpiry;
    await user.save();

    await transporter.sendMail({
      from: 'shubhamrawat8249@gmail.com',
      to: email,
      subject: 'OTP for Registration',
      text: `Your OTP is ${otp}. It is valid for 10 minutes.`,
    });

    res.status(200).json({ message: 'OTP resent successfully. Please check your email.' });
  } catch (error) {
    console.error('Error resending OTP:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
}
 
exports.login = async (req, res) => {
  try {
    const { email, password } = req.body;
    const user = await User.findOne({ email });     

    if (!user) {
      return res.status(400).json({ message: 'User not found' });
    }
     if (user.password !== password) {
      return res.status(400).json({ message: 'Invalid password' });
    }
    if (!user.isVerified) {
      return res.status(400).json({ message: 'User not verified' });
    }
   req.session.user = {id: user._id, email: user.email};
    res.status(200).json({ message: 'Login successful', user: { id: user._id, email: user.email } });
  } catch (error) {
    res.status(500).json({ message: 'Internal server error' });
  }
}

exports.logout = async (req, res) => {
 
    req.session.destroy((err) => {
      if (err) 
        return res.status(500).json({ message: 'Error logging out' });
        res.json({ message: 'Logout successful' });
    });
}
 
exports.dashboard = async (req, res) => {
    res.json({ message: 'Welcome to the dashboard', user: req.session.user });
}