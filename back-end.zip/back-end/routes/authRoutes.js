const express = require('express');
const {register, verifyOTP, resendOTP, login, logout, dashboard} = require('../controllers/authController');
const authMiddware = require('../middleware/authmiddleware');
const router = express.Router();

router.post('/register', register);
router.post('/verify-otp', verifyOTP);
router.post('/resend-otp', resendOTP);
router.post('/login', login);
router.post('/logout', authMiddware, logout);    
router.get('/dashboard', authMiddware, dashboard); // Protected route

module.exports = router;